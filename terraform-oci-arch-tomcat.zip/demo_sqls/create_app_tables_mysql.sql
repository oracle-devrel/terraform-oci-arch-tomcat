use ${oci_mds_db_name};
select * from todos;
